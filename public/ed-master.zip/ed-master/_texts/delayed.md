---
layout: poem
title: Delayed till she had ceased to know
author: Emily Dickinson
source: Bartleby.com
---

<p class="citation"> by {{ page.author }}</p>

<br>

- DELAYED till she had ceased to know,	
- Delayed till in its vest of snow	
- {:.indent-2}Her loving bosom lay.	
- An hour behind the fleeting breath,	
- Later by just an hour than death,—
- {:.indent-2}Oh, lagging yesterday!	


- Could she have guessed that it would be;	
- Could but a crier of the glee	
- {:.indent-2}Have climbed the distant hill;
- Had not the bliss so slow a pace,—
- Who knows but this surrendered face	
- {:.indent-2}Were undefeated still?


- Oh, if there may departing be	
- Any forgot by victory	
- {:.indent-2}In her imperial round,
- Show them this meek apparelled thing,	
- That could not stop to be a king,	
- {:.indent-2}Doubtful if it be crowned!