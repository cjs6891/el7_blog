---
layout: drama
title: A Raisin in the Sun
author: Lorraine Hansberry
source: "Hansberry, Lorraine, and Robert Nemiroff. A Raisin in the Sun. Rep Rei edition. New York: Vintage, 2004. Print."

---

<p class="citation"> by {{ page.author }}</p>

(excerpt)

MAMA: Son—how come you talk so much 'bout money?

WALTER (*with immense passion*): Because it is life, Mama!

MAMA: Oh—So now it’s life. Money is life. Once upon a time freedom used to be life—now it’s money. I guess the world really do change ...

WALTER: No—it was always money, Mama. We just didn’t know about it.

MAMA: No . . . something has changed. (*She looks at him*) You something new, boy. In my time we was worried about not being lynched and getting to the North if we could and how to stay alive and still have a pinch of dignity too ... Now here come you and Beneatha—talking 'bout things we never even thought about hardly, me and your daddy. You ain’t satisfied or proud of nothing we done. I mean that you had a home; that we kept you out of trouble till you was grown; that you don’t have to ride to work on the back of nobody’s streetcar—You my children—but how different we done become.