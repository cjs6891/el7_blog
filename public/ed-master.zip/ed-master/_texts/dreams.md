---
layout: poem
title: Dreams
author: Langston Hughes
source: Project Guttenberg
---

- Hold fast to dreams
- For if dreams die
- Life is a broken-winged bird
- That cannot fly.
- Hold fast to dreams
- For when dreams go
- Life is a barren field
- Frozen with snow.

<p class="citation">{{ page.author }}</p>

